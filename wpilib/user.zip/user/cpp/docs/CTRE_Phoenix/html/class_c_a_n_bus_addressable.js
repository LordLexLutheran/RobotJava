var class_c_a_n_bus_addressable =
[
    [ "CANBusAddressable", "class_c_a_n_bus_addressable.html#aeb31f9c2c7535f3ff6f7555f72a9b6f8", null ],
    [ "GetDeviceNumber", "class_c_a_n_bus_addressable.html#a733c10c4253e71a195329587b0b60aa5", null ]
];