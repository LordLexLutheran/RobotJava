var dir_425d34dbc132aa13b0d22ba714144371 =
[
    [ "GadgeteerUartClient.h", "_gadgeteer_uart_client_8h.html", [
      [ "IGadgeteerUartClient", "class_i_gadgeteer_uart_client.html", "class_i_gadgeteer_uart_client" ],
      [ "GadgeteerUartStatus", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html", "struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status" ]
    ] ]
];