var NAVTREE =
[
  [ "CTRE_Phoenix", "index.html", [
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", "namespacemembers_eval" ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_base_motor_controller_8cpp.html",
"_mot_controller___c_c_i_8h.html#a2224690b6fc808587e0be6b64b657bf5",
"_stopwatch_8h.html",
"classctre_1_1phoenix_1_1motorcontrol_1_1_control_frame_routines.html",
"classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html#a2af8e20328c05c0cead13653dd9ca579",
"classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a0e3afedea20bfe5e9fb43adb2f8be194",
"dir_6cc22f41418063b0c9fbb388ba8b8cad.html",
"signal_types_8h.html#a06fc87d81c62e9abb8790b6e5713c55bad8f2c7201737c891eb150f3569eaf095"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';