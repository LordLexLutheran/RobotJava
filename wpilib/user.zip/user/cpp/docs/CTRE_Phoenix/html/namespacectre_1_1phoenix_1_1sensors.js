var namespacectre_1_1phoenix_1_1sensors =
[
    [ "PigeonIMU", "classctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u.html", "classctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u" ],
    [ "PigeonIMU_Faults", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u___faults.html", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u___faults" ],
    [ "PigeonIMU_StickyFaults", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u___sticky_faults.html", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u___sticky_faults" ]
];