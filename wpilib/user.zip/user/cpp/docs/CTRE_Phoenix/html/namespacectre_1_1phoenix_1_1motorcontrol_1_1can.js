var namespacectre_1_1phoenix_1_1motorcontrol_1_1can =
[
    [ "BaseMotorController", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller.html", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller" ],
    [ "TalonSRX", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_talon_s_r_x.html", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_talon_s_r_x" ],
    [ "VictorSPX", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x" ],
    [ "WPI_TalonSRX", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_w_p_i___talon_s_r_x.html", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_w_p_i___talon_s_r_x" ],
    [ "WPI_VictorSPX", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_w_p_i___victor_s_p_x.html", "classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_w_p_i___victor_s_p_x" ]
];