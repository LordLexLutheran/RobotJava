var class_low_level_c_a_nifier =
[
    [ "GeneralPin", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291", [
      [ "QUAD_IDX", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291aed72d6bb48d31841b82b39fda588976f", null ],
      [ "QUAD_B", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a881d5c9d209bee9c5d7d30d037656f03", null ],
      [ "QUAD_A", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a03b5d830d079bc3bb6db7751850bb31c", null ],
      [ "LIMR", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a313bea1f78a86af97791ec66ba9d0ce1", null ],
      [ "LIMF", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a48fb44f63c0927d81e718725e438cba0", null ],
      [ "SDA", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291add7d4d825dc18d2a9c4e89b55539a006", null ],
      [ "SCL", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a995389df6e4564500e5aa312db980f18", null ],
      [ "SPI_CS", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a5244c435d4b0ab02bde3dfcca9fa3831", null ],
      [ "SPI_MISO_PWM2P", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a36eb6a17b8a21ff8e945f065d9d2f65e", null ],
      [ "SPI_MOSI_PWM1P", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291ab06b2b28ed7deca781439409756bdbae", null ],
      [ "SPI_CLK_PWM0P", "class_low_level_c_a_nifier.html#afe41e644f62c52c7a84381f6bd21e291a629e56e4f20fb0e5fbe83dcc97106b60", null ]
    ] ],
    [ "LowLevelCANifier", "class_low_level_c_a_nifier.html#ab78de2e1ad287dca38b3d25988382132", null ],
    [ "ClearStickyFaults", "class_low_level_c_a_nifier.html#ac3f8f23302fdfb8c1c3115ebdf49f2b1", null ],
    [ "EnablePWMOutput", "class_low_level_c_a_nifier.html#a3285ccef09ba446c901f8af0fb948fbd", null ],
    [ "GetBatteryVoltage", "class_low_level_c_a_nifier.html#ab5f5f7d863670130fcc58b405b2be1aa", null ],
    [ "GetFaults", "class_low_level_c_a_nifier.html#aa1e11aaf28bfbef367b7b63830da15b1", null ],
    [ "GetGeneralInput", "class_low_level_c_a_nifier.html#a82335d5701d62df5526616506c2f4353", null ],
    [ "GetGeneralInputs", "class_low_level_c_a_nifier.html#a0c9bd4b84500eb996a55e845d49a0c66", null ],
    [ "GetLastError", "class_low_level_c_a_nifier.html#a14759e1b7993c3777d9a271d5e2a57c3", null ],
    [ "GetPWMInput", "class_low_level_c_a_nifier.html#a0e630dcacb1355f65f2ecc4c6e5971d7", null ],
    [ "GetStatusFramePeriod", "class_low_level_c_a_nifier.html#ae977281ee9564abb980df59ea4f8c090", null ],
    [ "GetStickyFaults", "class_low_level_c_a_nifier.html#ad1acb844c61c659b4ed8ab6f5548474c", null ],
    [ "SetControlFramePeriod", "class_low_level_c_a_nifier.html#a5b4e2b2167d53f6ac18909b671f86dc5", null ],
    [ "SetGeneralOutput", "class_low_level_c_a_nifier.html#a39ffc487640ef3c1dba64d8132d3bdb4", null ],
    [ "SetGeneralOutputs", "class_low_level_c_a_nifier.html#acf138b512ee9436c68cbe146debb187e", null ],
    [ "SetLastError", "class_low_level_c_a_nifier.html#a3325ac94770115ba5fae567a2a1b488f", null ],
    [ "SetLEDOutput", "class_low_level_c_a_nifier.html#ad6c714ae004631be8edaffab66ce0a89", null ],
    [ "SetPWMOutput", "class_low_level_c_a_nifier.html#a361a4a3838446ad39747e699feeb0b27", null ],
    [ "SetStatusFramePeriod", "class_low_level_c_a_nifier.html#a295535c9a60eed0c610a3e9b1c278184", null ]
];