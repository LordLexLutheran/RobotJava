var searchData=
[
  ['kanalog',['kAnalog',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843a4d8a246da67644080d3b7d3c20216c56',1,'signalTypes.h']]],
  ['kpulsewidthencodedposition',['kPulseWidthEncodedPosition',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843ae2d31a88e661cb6b91786515c6fbafa0',1,'signalTypes.h']]],
  ['kquadencoder',['kQuadEncoder',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843a579f915f6371d2855d85506722c93943',1,'signalTypes.h']]],
  ['kremotesensor0',['kRemoteSensor0',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843abbb8a5d73bd6907c13e47d1bb73528eb',1,'signalTypes.h']]],
  ['kremotesensor1',['kRemoteSensor1',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843ade1383677234b9dbcc1b7b6ad53e837b',1,'signalTypes.h']]],
  ['ksensordifference',['kSensorDifference',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843ad7e2e49803dd3135a5bb88ecc46272c8',1,'signalTypes.h']]],
  ['ksensorsum',['kSensorSum',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843a316844ac8e1415fd59a4121a083963d7',1,'signalTypes.h']]],
  ['ksoftwaremulatedsensor',['kSoftwarEmulatedSensor',['../signal_types_8h.html#a96f7c17b53541a8bff222ec823683843abf2d18af672aabc94bb2b1ca05a2cd69',1,'signalTypes.h']]]
];
