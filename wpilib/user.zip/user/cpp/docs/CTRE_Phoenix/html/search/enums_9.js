var searchData=
[
  ['sensorterm',['SensorTerm',['../namespacectre_1_1phoenix_1_1motorcontrol.html#a4f84db28c2d27cd678c7c1e867ba10c5',1,'ctre::phoenix::motorcontrol']]],
  ['setvaluemotionprofile',['SetValueMotionProfile',['../namespacectre_1_1phoenix_1_1motion.html#ae14983694711f8fd190f3ba197eb9095',1,'ctre::phoenix::motion']]],
  ['status',['Status',['../classctre_1_1phoenix_1_1_r_c_radio3_ch.html#af99fce9bcc1e054733746ab7bf3c1389',1,'ctre::phoenix::RCRadio3Ch']]],
  ['statusframe',['StatusFrame',['../namespacectre_1_1phoenix_1_1motorcontrol.html#adbcb3ed785a15b4a47b54d1130467087',1,'ctre::phoenix::motorcontrol']]],
  ['statusframeenhanced',['StatusFrameEnhanced',['../namespacectre_1_1phoenix_1_1motorcontrol.html#a2eb61fd8d8bfb6f8308a740f7d94abf0',1,'ctre::phoenix::motorcontrol']]]
];
