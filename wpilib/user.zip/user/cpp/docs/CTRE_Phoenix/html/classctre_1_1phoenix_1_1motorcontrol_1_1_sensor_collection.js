var classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection =
[
    [ "GetAnalogIn", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a8efebfe80c3304fcb5d8265621d9c1f9", null ],
    [ "GetAnalogInRaw", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a4170b7f3c45ee15607e932b018247c35", null ],
    [ "GetAnalogInVel", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#aae533eda8864c400732d1b8585c789f6", null ],
    [ "GetPinStateQuadA", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#aef177ac5872146d5235fcf43b799775c", null ],
    [ "GetPinStateQuadB", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#ac05c29650827ef0ac9e2e12bc9fd5602", null ],
    [ "GetPinStateQuadIdx", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#ad3150d0e48e7f54fc3cf65a67ca71746", null ],
    [ "GetPulseWidthPosition", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a7d34fc91c4fc67667b7ee8a8d1f02253", null ],
    [ "GetPulseWidthRiseToFallUs", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#ac9d6c6331a05993b8efed08d31dd764a", null ],
    [ "GetPulseWidthRiseToRiseUs", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#ad6b2b1c970820e302989d96d72fb8d37", null ],
    [ "GetPulseWidthVelocity", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a7a54a36e97e5825179a10dd12832a935", null ],
    [ "GetQuadraturePosition", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#ab85fc2d341c7d4b7419e430b85969af1", null ],
    [ "GetQuadratureVelocity", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a4635f151a1b189cd3fe62df8c710b1fc", null ],
    [ "IsFwdLimitSwitchClosed", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a53dbbc39ac81ce282beb74b68d028af9", null ],
    [ "IsRevLimitSwitchClosed", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a1908b2ac408955e6a2311c53a95cdff6", null ],
    [ "SetAnalogPosition", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a81930bcaa7dc8243b132d6cf7ac97108", null ],
    [ "SetPulseWidthPosition", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#aced6a17febd768c722024ed75fd3eab4", null ],
    [ "SetQuadraturePosition", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a729c843cdf5b2360a3a39602a910b58d", null ],
    [ "ctre::phoenix::motorcontrol::can::BaseMotorController", "classctre_1_1phoenix_1_1motorcontrol_1_1_sensor_collection.html#a427e0235c885480b81a6b5e9ce8f573e", null ]
];