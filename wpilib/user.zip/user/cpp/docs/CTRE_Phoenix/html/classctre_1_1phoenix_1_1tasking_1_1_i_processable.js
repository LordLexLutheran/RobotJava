var classctre_1_1phoenix_1_1tasking_1_1_i_processable =
[
    [ "~IProcessable", "classctre_1_1phoenix_1_1tasking_1_1_i_processable.html#a18ba9f323944f9bf8985f13d82f50a02", null ],
    [ "Process", "classctre_1_1phoenix_1_1tasking_1_1_i_processable.html#ad0aec1648b0d9fa1a3e1465b35c7c405", null ]
];